﻿using System;

namespace MegaCrit.Sts2.Core.Hooks
{
	/// <summary>
	/// Represents the type(s) of ModifyDamage hooks that should be run for a given instance of damage.
	/// </summary>
	// Token: 0x02000C00 RID: 3072
	[Flags]
	public enum ModifyDamageHookType
	{
		// Token: 0x04002A78 RID: 10872
		None = 0,
		/// <summary>
		/// Additive damage hooks from effects like <see cref="T:MegaCrit.Sts2.Core.Models.Powers.StrengthPower" />.
		/// Including this will cause <see cref="M:MegaCrit.Sts2.Core.Models.AbstractModel.ModifyDamageAdditive(MegaCrit.Sts2.Core.Entities.Creatures.Creature,System.Decimal,MegaCrit.Sts2.Core.ValueProps.ValueProp,MegaCrit.Sts2.Core.Entities.Creatures.Creature,MegaCrit.Sts2.Core.Models.CardModel,MegaCrit.Sts2.Core.Entities.Cards.CardPlay)" /> and
		/// <see cref="M:MegaCrit.Sts2.Core.Models.EnchantmentModel.EnchantDamageAdditive(System.Decimal,MegaCrit.Sts2.Core.ValueProps.ValueProp)" /> to be called.
		/// At the time of this writing (5/15/2026), we never use this type alone.
		/// If that changes, please update this comment.
		/// </summary>
		// Token: 0x04002A79 RID: 10873
		Additive = 2,
		/// <summary>
		/// Multiplicative damage hooks from effects like <see cref="T:MegaCrit.Sts2.Core.Models.Powers.VulnerablePower" />.
		/// Including this will cause <see cref="M:MegaCrit.Sts2.Core.Models.AbstractModel.ModifyDamageMultiplicative(MegaCrit.Sts2.Core.Entities.Creatures.Creature,System.Decimal,MegaCrit.Sts2.Core.ValueProps.ValueProp,MegaCrit.Sts2.Core.Entities.Creatures.Creature,MegaCrit.Sts2.Core.Models.CardModel,MegaCrit.Sts2.Core.Entities.Cards.CardPlay)" /> and
		/// <see cref="M:MegaCrit.Sts2.Core.Models.EnchantmentModel.EnchantDamageMultiplicative(System.Decimal,MegaCrit.Sts2.Core.ValueProps.ValueProp)" /> to be called.
		/// At the time of this writing (5/15/2026), we never use this type alone.
		/// If that changes, please update this comment.
		/// </summary>
		// Token: 0x04002A7A RID: 10874
		Multiplicative = 4,
		/// <summary>
		/// Damage-capping hooks from effects like <see cref="T:MegaCrit.Sts2.Core.Models.Powers.IntangiblePower" />.
		/// Including this will cause <see cref="M:MegaCrit.Sts2.Core.Models.AbstractModel.ModifyDamageCap(MegaCrit.Sts2.Core.Entities.Creatures.Creature,MegaCrit.Sts2.Core.ValueProps.ValueProp,MegaCrit.Sts2.Core.Entities.Creatures.Creature,MegaCrit.Sts2.Core.Models.CardModel,MegaCrit.Sts2.Core.Entities.Cards.CardPlay)" /> to be called.
		/// At the time of this writing (5/15/2026), we never use this type alone.
		/// If that changes, please update this comment.
		/// </summary>
		// Token: 0x04002A7B RID: 10875
		Cap = 8,
		/// <summary>
		/// Include all ModifyDamage hooks.
		/// Most back-end ModifyDamage hook calls will use this.
		/// </summary>
		// Token: 0x04002A7C RID: 10876
		All = 14
	}
}
